const awardCategoriesData = {
  title: "List Of Award Categories",
  percentageBoxes: [
    {
      logo: require("./circle.png").default,
      title: "25%",
      description: "Lorem ipsum dolor sit",
    },
    {
      logo: require("./circle.png").default,
      title: "25%",
      description: "Lorem ipsum dolor sit",
    },
    {
      logo: require("./circle.png").default,
      title: "25%",
      description: "Lorem ipsum dolor sit",
    },
    {
      logo: require("./circle.png").default,
      title: "25%",
      description: "Lorem ipsum dolor sit",
    },
  ],
  listing: [
    {
      link: "#",
      points: [
        "4, Directed by Dylan Garcia (Arizona)",
        "Angie Baby, Directed by Jacob Mullen (United States)",
        "Black Moon, Directed by Ryan Graff (California)",
        "CLASS, Directed by Enzo Cellucci, Ash McNair (New York)",
        "Exterminator, Directed by Duncan Birmingham (California)",
        "Granny’s Treasures, Directed by Kevin R. Phipps (Arizona)",
        "4, Directed by Dylan Garcia (Arizona)",
        "Angie Baby, Directed by Jacob Mullen (United States)",
        "Black Moon, Directed by Ryan Graff (California)",
        "CLASS, Directed by Enzo Cellucci, Ash McNair (New York)",
        "Exterminator, Directed by Duncan Birmingham (California)",
        "Granny’s Treasures, Directed by Kevin R. Phipps (Arizona)",
      ],
      buyTicketsLink: "#",
    },
    {
      link: "#",
      points: [
        "4, Directed by Dylan Garcia (Arizona)",
        "Angie Baby, Directed by Jacob Mullen (United States)",
        "Black Moon, Directed by Ryan Graff (California)",
        "CLASS, Directed by Enzo Cellucci, Ash McNair (New York)",
        "Exterminator, Directed by Duncan Birmingham (California)",
        "Granny’s Treasures, Directed by Kevin R. Phipps (Arizona)",
      ],
      buyTicketsLink: "#",
    },
  ],
}

export default awardCategoriesData
