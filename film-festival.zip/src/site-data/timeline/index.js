import Logo1 from "./1.png"
import Logo2 from "./2.png"
import Logo3 from "./3.png"
import Logo4 from "./4.png"

const TIMELINE_DATA = [
  {
    date: "March 27, 2021",
    title: "Nevada Short Film Festival",
    description:
      "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nulla vitae delectus, et natus doloremque fugiat expedita molestiae impedit. Eaque, nihil.",
    link: "#",
    logo: Logo1,
  },
  {
    date: "March 27, 2021",
    title: "Reno Comedy Film Festival",
    description:
      "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nulla vitae delectus, et natus doloremque fugiat expedita molestiae impedit. Eaque, nihil.",
    link: "#",
    logo: Logo3,
  },
  {
    date: "May 1, 2021",
    title: "Houston Comedy Film Festival",
    description:
      "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nulla vitae delectus, et natus doloremque fugiat expedita molestiae impedit. Eaque, nihil.",
    link: "#",
    logo: Logo2,
  },
  {
    date: "May 1, 2021",
    title: "Houston Comedy Film Festival",
    description:
      "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Nulla vitae delectus, et natus doloremque fugiat expedita molestiae impedit. Eaque, nihil.",
    link: "#",
    logo: Logo4,
  },
]

export default TIMELINE_DATA
