const featuresData = {
  title: "What Is The Film Festival Circuit?",
  featureBoxes: [
    {
      logo: require("./video-camera.png").default,
      title: "Lorem ipsum dolor sit",
      description:
        "Lorem ipsum dolor sit amet, consectet adipiscing elit. Phasellus id erat nec dol interdum pretium sit amet sit amet nib. Pellentesque eget erat nulla pelle.",
    },
    {
      logo: require("./auction.png").default,
      title: "Lorem ipsum dolor sit",
      description:
        "Lorem ipsum dolor sit amet, consectet adipiscing elit. Phasellus id erat nec dol interdum pretium sit amet sit amet nib. Pellentesque eget erat nulla pelle.",
    },
    {
      logo: require("./chat.png").default,
      title: "Lorem ipsum dolor sit",
      description:
        "Lorem ipsum dolor sit amet, consectet adipiscing elit. Phasellus id erat nec dol interdum pretium sit amet sit amet nib. Pellentesque eget erat nulla pelle.",
    },
  ],
}

export default featuresData
