const latestBlogsData = {
  title: "Latest From Our Blog",
  description:
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris vitae fringilla magna.",
  linkText: "View More Blogs",
  blogs: [
    {
      image: require("./latest-blog.jpg").default,
      title: "Lorem Ipsum Dolor",
      description:
        "Lorem ipsum dolor sit amet, consecteture im adipiscing elit. Etiam auctor sit ametisil diam ne molestie phasellus.",
      readMoreText: "READ MORE",
    },
    {
      image: require("./latest-blog.jpg").default,
      title: "Lorem Ipsum Dolor",
      description:
        "Lorem ipsum dolor sit amet, consecteture im adipiscing elit. Etiam auctor sit ametisil diam ne molestie phasellus.",
      readMoreText: "READ MORE",
    },
    {
      image: require("./latest-blog.jpg").default,
      title: "Lorem Ipsum Dolor",
      description:
        "Lorem ipsum dolor sit amet, consecteture im adipiscing elit. Etiam auctor sit ametisil diam ne molestie phasellus.",
      readMoreText: "READ MORE",
    },
  ],
}

export default latestBlogsData
