const heroSectionData = {
  heroBgImage: require("./hero-bg.jpg"),
  heroSliderContent: [
    {
      title: "Free Virtual Networking. Join Now!",
      description:
        "Our industry is changing fast. Stay connected. Join us for free virtual networking events for filmmakers, screenwriters, producers, investors, distributors, cast, crew and content creators in the film and television industry.",
    },
    {
      title: "Free Virtual Networking. Join Now!",
      description:
        "Our industry is changing fast. Stay connected. Join us for free virtual networking events for filmmakers, screenwriters, producers, investors, distributors, cast, crew and content creators in the film and television industry.",
    },
    {
      title: "Free Virtual Networking. Join Now!",
      description:
        "Our industry is changing fast. Stay connected. Join us for free virtual networking events for filmmakers, screenwriters, producers, investors, distributors, cast, crew and content creators in the film and television industry.",
    },
    {
      title: "Free Virtual Networking. Join Now!",
      description:
        "Our industry is changing fast. Stay connected. Join us for free virtual networking events for filmmakers, screenwriters, producers, investors, distributors, cast, crew and content creators in the film and television industry.",
    },
  ],
  nextIcon: require("../../assets/right-arrow.png").default,
  prevIcon: require("../../assets/left-arrow.png").default,
}

export default heroSectionData
