const reviewsSectionData = {
  title: "See What Our Users Are Saying About Us",
  nextIcon: require("../../assets/right-arrow.png"),
  prevIcon: require("../../assets/left-arrow.png"),
  reviews: [
    {
      reviewerAvatar: "",
      review:
        "Lorem ipsum dolor sit amet, consectetur adipisc elit. In nonim consectetur, dui a bibendum interdum, nibh mollis mi, non rut ex libero at enim.",
      reviewer: "Name of Reviewer",
      jobTitle: "Job Title",
      occupation: "Occupation",
      rating: 3,
    },
    {
      reviewerAvatar: "",
      review:
        "Lorem ipsum dolor sit amet, consectetur adipisc elit. In nonim consectetur, dui a bibendum interdum, nibh mollis mi, non rut ex libero at enim.",
      reviewer: "Name of Reviewer",
      jobTitle: "Job Title",
      occupation: "Occupation",
      rating: 3,
    },
    {
      reviewerAvatar: "",
      review:
        "Lorem ipsum dolor sit amet, consectetur adipisc elit. In nonim consectetur, dui a bibendum interdum, nibh mollis mi, non rut ex libero at enim.",
      reviewer: "Name of Reviewer",
      jobTitle: "Job Title",
      occupation: "Occupation",
      rating: 3,
    },
    {
      reviewerAvatar: "",
      review:
        "Lorem ipsum dolor sit amet, consectetur adipisc elit. In nonim consectetur, dui a bibendum interdum, nibh mollis mi, non rut ex libero at enim.",
      reviewer: "Name of Reviewer",
      jobTitle: "Job Title",
      occupation: "Occupation",
      rating: 3,
    },
  ],
}

export default reviewsSectionData
