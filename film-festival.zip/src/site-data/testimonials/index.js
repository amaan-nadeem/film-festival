const testimonialsData = {
  title: "Testimonials",
  description:
    "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris vitae fringilla magna.",
  testimonials: [
    {
      avatar: require("./avatar.jpg").default,
      title: "John Doe",
      description:
        "Lorem ipsum dolor sit amet, consec adipisc elit. Morbi felis risus, elementum porttitor vita, ullamcorper dictum.",
      occupation: "Occupation",
      ratings: 4,
    },
    {
      avatar: require("./avatar.jpg").default,
      title: "John Doe",
      description:
        "Lorem ipsum dolor sit amet, consec adipisc elit. Morbi felis risus, elementum porttitor vita, ullamcorper dictum.",
      occupation: "Occupation",
      ratings: 4,
    },
    {
      avatar: require("./avatar.jpg").default,
      title: "John Doe",
      description:
        "Lorem ipsum dolor sit amet, consec adipisc elit. Morbi felis risus, elementum porttitor vita, ullamcorper dictum.",
      occupation: "Occupation",
      ratings: 4,
    },
    {
      avatar: require("./avatar.jpg").default,
      title: "John Doe",
      description:
        "Lorem ipsum dolor sit amet, consec adipisc elit. Morbi felis risus, elementum porttitor vita, ullamcorper dictum.",
      occupation: "Occupation",
      ratings: 4,
    },
    {
      avatar: require("./avatar.jpg").default,
      title: "John Doe",
      description:
        "Lorem ipsum dolor sit amet, consec adipisc elit. Morbi felis risus, elementum porttitor vita, ullamcorper dictum.",
      occupation: "Occupation",
      ratings: 4,
    },
    {
      avatar: require("./avatar.jpg").default,
      title: "John Doe",
      description:
        "Lorem ipsum dolor sit amet, consec adipisc elit. Morbi felis risus, elementum porttitor vita, ullamcorper dictum.",
      occupation: "Occupation",
      ratings: 4,
    },
  ],
}

export default testimonialsData
