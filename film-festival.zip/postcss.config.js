module.exports = () => ({
    plugins: [require("tailwindcss")],
  })